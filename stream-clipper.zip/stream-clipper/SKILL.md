---
name: stream-clipper
description: Turn long streams and VODs (up to 24 hours) into 30 second to 2 minute vertical 9:16 clips with clean word-highlight captions and punch-in zooms, fully free, local, and with no watermark. Use this skill whenever the user wants to clip a stream, find highlights or best moments in a long video, make Shorts, TikToks or Reels from a livestream, VOD, podcast or YouTube/Twitch/Kick link, add captions and zooms to clips, or asks for a free OpusClip alternative, even if they never say "skill" or "script".
---

# Stream Clipper

Clips long streams automatically using a bundled script (`scripts/clip_stream.py`) that runs on the user's own machine with free tools (ffmpeg, yt-dlp, faster-whisper). It exists because free web clippers cap minutes or add watermarks, and none handle 24-hour streams well.

## What the script does

1. Gets audio only (for URLs, a small audio download rather than the whole video).
2. Scores the entire stream by loudness and energy, so no slow transcription of 24 hours.
3. Transcribes only the best candidate regions (`--mode fast`, the default), or everything with `--mode full`.
4. Re-ranks by energy, speech density, and hype keywords, then snaps each clip to sentence boundaries and keeps it between 30 and 120 seconds.
5. Renders 9:16 MP4s with word-highlight captions, a zoom push every few seconds, and normalized loudness. For URLs it downloads only the chosen sections of video.

Moment picking is signal-based (loud, fast, hype words), not a true "virality" model. Say so honestly when it matters, and offer the review step below.

## Workflow

1. **Collect the minimum.** Source (URL or file), and optionally: number of clips, content type. Do not interrogate. If missing, use defaults (10 clips, 30-120s) and ask at most one question. The one worth asking: is it gameplay/with a facecam (use `--layout blur`) or a talking-head stream (use `--layout center`, adjust `--crop-x`)?
2. **Check what is possible here.** This sandbox usually has no internet, and 24-hour streams are far too large to process in it. Only run the script yourself when a video file exists under `/mnt/user-data/uploads` and ffmpeg is available. Never claim to have processed a video you did not run. Otherwise, deliver the script and a ready-to-paste command (step 3).
3. **Give the user a ready command**, built from their answers. Copy `scripts/clip_stream.py` to `/mnt/user-data/outputs/` and present it. Point to `references/setup.md` for one-time installs (read it and give the user the OS-specific lines only). Example commands:
   - Default: `python clip_stream.py "URL" --out clips`
   - Gaming stream: `python clip_stream.py "URL" --layout blur`
   - 24h stream, 1 clip per hour: `python clip_stream.py "URL" --per-hour 1 --model base`
   - NVIDIA GPU: add `--encoder h264_nvenc`
   - Hype words for their game or community: `--keywords "clutch,ace,let's go"`
4. **Offer a review pass.** `--dry-run` picks moments and writes `clips.json` (rank, timestamps, transcript text) without rendering. If the user pastes it back, rank the clips by hook strength and suggest titles, then tell them to render only the keepers with `--only 1,3,5`. The cache makes re-runs fast.
5. **Remind about rights** once: only clip streams they own or have permission to reuse.

## Tuning reference

| Goal | Flag |
|---|---|
| Fewer/more clips | `--clips N` or `--per-hour X` |
| Shorter/longer clips | `--min 30 --max 120 --target 75` |
| Faster on CPU | `--model tiny` or `base` (accuracy drops slightly) |
| Better captions | `--model medium` / `large-v3` (needs GPU) |
| Facecam on one side | `--crop-x 0` (left) to `1` (right), or `--layout blur` |
| Bigger/lower captions | `--font-size 96 --caption-margin 380` |
| No zoom / slower zoom | `--no-zoom` / `--zoom-beat 8` |
| Lowercase captions | `--no-caps` |
| Smaller downloads | `--max-height 720` |

## Expectations to set

- Fast mode on a 24h stream: audio download and analysis take minutes; transcribing ~25-40 candidate regions is the slow part (tens of minutes on CPU, much faster with a GPU).
- Disk: about 2.8 GB of temporary audio for a 24h stream, in `<out>/.cache`.
- First run downloads the Whisper model.
- Captions are only as accurate as Whisper on the stream's audio; loud game or music audio lowers accuracy.

If something fails, read `references/setup.md` (troubleshooting section) before guessing.
