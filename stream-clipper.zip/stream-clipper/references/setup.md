# Setup and troubleshooting

## One-time install

1. **Python 3.9+**: https://www.python.org (on Windows tick "Add Python to PATH").
2. **ffmpeg** (must include libass, the standard builds do):
   - Windows: `winget install ffmpeg`
   - Mac: `brew install ffmpeg`
   - Linux: `sudo apt install ffmpeg`
3. **Python packages**: `pip install numpy faster-whisper yt-dlp`

Check with: `ffmpeg -version` and `yt-dlp --version`.

## Troubleshooting

- **`yt-dlp` fails or is outdated**: `pip install -U yt-dlp`. Live streams still in progress may not be downloadable until they finish processing; wait for the VOD.
- **"No usable speech found"**: the loud moments had no talking (music/game audio). Try `--mode full`, a bigger `--model`, or `--keywords` that match the stream.
- **Captions use the wrong font or look plain**: install the font or pass `--font "Font Name"`. On Linux Arial may be missing; try `--font "DejaVu Sans"`.
- **Subtitles filter error on Windows**: run from the folder where you want output and avoid special characters in `--out`.
- **Crop cuts off the action**: use `--layout blur`, or `--crop-x` to shift the crop window.
- **Out of disk**: the cache holds ~2.8 GB audio per 24h. Delete `<out>/.cache` when finished.
- **Too slow**: `--model tiny`, use `--encoder h264_nvenc` on NVIDIA GPUs, lower `--per-hour`.
- **Resume after a crash**: re-run the same command; finished steps are cached.
