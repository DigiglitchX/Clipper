#!/usr/bin/env python3
"""
clip_stream.py - turn a long stream (up to 24h+) into 30s-2min vertical clips
with clean word-highlight captions and punch-in zooms. Free, local, no watermark.

Pipeline (built so 24h streams stay practical):
  1. Get audio only (URLs: audio-only download, tiny compared to video).
  2. Score the whole stream by loudness/energy in seconds (no transcription yet).
  3. Transcribe ONLY the best candidate regions with faster-whisper (fast mode),
     or everything (--mode full).
  4. Re-rank candidates (energy + speech density + keywords), snap clips to
     sentence boundaries, keep each clip between --min and --max seconds.
  5. Render 9:16 MP4s with burned-in captions and zoom beats.
     For URLs only the chosen sections of video are downloaded.

Everything is cached in <out>/.cache, so re-running (e.g. with another layout)
skips finished steps.
"""
import argparse, json, math, re, shutil, subprocess, sys, wave
from pathlib import Path
import numpy as np

SR = 16000
DEFAULT_KEYWORDS = ("insane,crazy,no way,let's go,lets go,oh my god,omg,clutch,wow,"
                    "holy,what the,unbelievable,finally,i can't believe,world record,"
                    "oh no,dude,bro,wait")


def sh(cmd, **kw):
    subprocess.run([str(c) for c in cmd], check=True, **kw)


def is_url(s):
    return s.startswith(("http://", "https://"))


def hms(t):
    t = int(t)
    return f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}"


def tag(t):
    t = int(t)
    return f"{t // 3600}h{t % 3600 // 60:02d}m{t % 60:02d}s"


def ass_ts(t):
    t = max(t, 0)
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


# ---------------------------------------------------------------- audio ----
def get_audio(args, cache):
    wav = cache / "audio.wav"
    if wav.exists():
        return wav
    if is_url(args.source):
        found = list(cache.glob("audio_src.*"))
        if not found:
            print("Downloading audio only (small)...")
            sh(["yt-dlp", "-f", "bestaudio/worst", "-o", cache / "audio_src.%(ext)s", args.source])
            found = list(cache.glob("audio_src.*"))
        inp = found[0]
    else:
        inp = Path(args.source)
    print("Converting audio for analysis...")
    sh(["ffmpeg", "-y", "-v", "error", "-i", inp, "-vn", "-ac", "1", "-ar", SR,
        "-c:a", "pcm_s16le", wav])
    return wav


def energy_per_second(wav):
    """RMS loudness for every second, read in chunks so 24h audio fits in memory."""
    out = []
    with wave.open(str(wav)) as w:
        while True:
            buf = w.readframes(SR * 600)
            if not buf:
                break
            x = np.frombuffer(buf, dtype=np.int16).astype(np.float32)
            k = len(x) // SR
            if k:
                out.append(np.sqrt((x[: k * SR].reshape(k, SR) ** 2).mean(axis=1)))
    return np.concatenate(out) if out else np.zeros(0)


def load_samples(wav, t0, t1):
    with wave.open(str(wav)) as w:
        w.setpos(max(0, int(t0 * SR)))
        buf = w.readframes(int((t1 - t0) * SR))
    return np.frombuffer(buf, dtype=np.int16).astype(np.float32) / 32768.0


# ----------------------------------------------------------- candidates ----
def find_candidates(e, k, win, stride=10, baseline=600):
    """Windows that are louder/more animated than their surroundings."""
    le = np.log1p(e)
    cs = np.concatenate([[0], np.cumsum(le)])
    spread = le.std() + 1e-6
    starts = list(range(0, max(1, len(le) - win), stride))
    scored = []
    for s in starts:
        seg = le[s:s + win]
        lo, hi = max(0, s - baseline), min(len(le), s + win + baseline)
        base = (cs[hi] - cs[lo]) / max(hi - lo, 1)
        mean = seg.mean()
        peak = np.percentile(seg, 90)
        scored.append(((mean - base) / spread + 0.5 * (peak - base) / spread + 0.3 * (mean - le.mean()) / spread))
    order = np.argsort(-np.array(scored))
    picked = []
    for i in order:
        s = starts[i]
        if all(abs(s - p[0]) >= win * 1.5 for p in picked):
            picked.append((s, float(scored[i])))
        if len(picked) >= k:
            break
    return picked


# ----------------------------------------------------------- transcript ----
_model = None


def get_model(size):
    global _model
    if _model is None:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            sys.exit("faster-whisper is missing. Run: pip install faster-whisper")
        print(f"Loading Whisper model '{size}' (first run downloads it)...")
        _model = WhisperModel(size, device="auto", compute_type="auto")
    return _model


def transcribe_range(wav, t0, t1, cache, size):
    f = cache / f"tr_{int(t0)}_{int(t1)}.json"
    if f.exists():
        return json.loads(f.read_text())
    model = get_model(size)
    audio = load_samples(wav, t0, t1)
    segs, _ = model.transcribe(audio, word_timestamps=True, vad_filter=True, beam_size=1)
    out = []
    for s in segs:
        words = [{"start": w.start + t0, "end": w.end + t0, "word": w.word.strip()}
                 for w in (s.words or []) if w.word.strip()]
        if words:
            out.append({"start": s.start + t0, "end": s.end + t0, "text": s.text.strip(), "words": words})
    f.write_text(json.dumps(out))
    return out


def transcribe_all(wav, total, cache, size):
    segs, step = [], 600
    for t0 in range(0, int(total), step):
        t1 = min(t0 + step, total)
        print(f"  transcribing {hms(t0)} - {hms(t1)}")
        segs += transcribe_range(wav, t0, t1, cache, size)
    return segs


# ------------------------------------------------------------ clip shape ----
def build_clip(segs, start, lo, hi, target):
    """Start at a sentence beginning near `start`, end on a sentence end."""
    cand = [s for s in segs if s["end"] > start - 3]
    if not cand:
        return None
    a = cand[0]["start"]
    b = a
    for s in cand:
        if s["start"] - b > 8 or s["end"] - a > hi:
            break
        b = s["end"]
        if b - a >= target:
            break
    if b - a < lo:
        b = a + lo
    spoken = sum(min(s["end"], b) - max(s["start"], a) for s in segs if s["end"] > a and s["start"] < b)
    if spoken < 0.3 * (b - a):
        return None
    return max(0, a - 0.3), b + 0.4


def zscore(x):
    x = np.asarray(x, dtype=np.float32)
    return (x - x.mean()) / (x.std() + 1e-6) if len(x) > 1 else np.zeros_like(x)


def segs_in(segs, a, b):
    return [s for s in segs if s["end"] > a and s["start"] < b]


# --------------------------------------------------------------- captions ----
def clean_word(w, caps):
    w = re.sub(r"[{}\\]", "", w)
    return w.upper() if caps else w


def make_ass(words, a, path, font, size, caps, margin_v):
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Cap,{font},{size},&H00FFFFFF,&H000000FF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,7,3,2,70,70,{margin_v},1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    groups, cur = [], []
    for w in words:
        if cur and (len(cur) >= 4 or w["start"] - cur[-1]["end"] > 0.7
                    or cur[-1]["word"].endswith((".", "?", "!"))):
            groups.append(cur)
            cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    lines = []
    for g in groups:
        for i, w in enumerate(g):
            start = w["start"] - a
            end = (g[i + 1]["start"] if i + 1 < len(g) else w["end"] + 0.25) - a
            end = max(end, start + 0.08)
            parts = []
            for j, x in enumerate(g):
                t = clean_word(x["word"], caps)
                parts.append("{\\c&H00E5FF&}" + t + "{\\c&HFFFFFF&}" if j == i else t)
            lines.append(f"Dialogue: 0,{ass_ts(start)},{ass_ts(end)},Cap,,0,0,0,,{' '.join(parts)}")
    path.write_text(head + "\n".join(lines) + "\n", encoding="utf-8")


# ----------------------------------------------------------------- render ----
def build_vf(args, ass_name):
    fps = 30
    if args.layout == "blur":
        base = ("split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,"
                "crop=1080:1920,boxblur=30:5[bg];[b]scale=1080:-2[fg];"
                "[bg][fg]overlay=(W-w)/2:(H-h)/2")
    else:
        base = f"crop=ih*9/16:ih:(iw-ow)*{args.crop_x}:0,scale=1080:1920"
    chain = [base, f"fps={fps}"]
    if not args.no_zoom:
        B = max(int(args.zoom_beat * fps), 1)
        z = f"1+0.10*mod(on,{B})/{B}+0.05*mod(floor(on/{B}),2)"
        chain += ["scale=1620:2880",
                  f"zoompan=z='{z}':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps={fps}"]
    chain += [f"subtitles={ass_name}", "format=yuv420p"]
    return ",".join(chain)


def render(src, ss, dur, ass, out, args):
    enc = {"libx264": ["-c:v", "libx264", "-preset", "fast", "-crf", "20"],
           "h264_nvenc": ["-c:v", "h264_nvenc", "-cq", "21"]}.get(
        args.encoder, ["-c:v", args.encoder, "-b:v", "8M"])
    sh(["ffmpeg", "-y", "-v", "error", "-ss", f"{ss:.2f}", "-i", src, "-t", f"{dur:.2f}",
        "-vf", build_vf(args, ass.name), "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
        *enc, "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out],
       cwd=ass.parent)


def fetch_section(url, a, b, dest, height):
    if dest.exists():
        return
    sec = f"*{hms(a)}-{hms(b)}"
    sh(["yt-dlp", "-f", f"bv*[height<={height}]+ba/b[height<={height}]",
        "--download-sections", sec, "--force-keyframes-at-cuts",
        "--merge-output-format", "mp4", "-o", dest, url])


# ------------------------------------------------------------------- main ----
def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("source", help="video URL (YouTube/Twitch/Kick...) or local file")
    p.add_argument("--out", default="clips")
    p.add_argument("--clips", type=int, default=10, help="how many clips (default 10)")
    p.add_argument("--per-hour", type=float, help="instead of --clips: clips per hour of stream")
    p.add_argument("--min", type=int, default=30, help="min clip seconds (default 30)")
    p.add_argument("--max", type=int, default=120, help="max clip seconds (default 120)")
    p.add_argument("--target", type=int, default=75, help="preferred clip seconds")
    p.add_argument("--mode", choices=["fast", "full"], default="fast",
                   help="fast: transcribe only candidate regions (best for 24h). full: transcribe everything")
    p.add_argument("--model", default="small", help="whisper model: tiny/base/small/medium/large-v3")
    p.add_argument("--transcript", help="optional JSON transcript to reuse instead of running Whisper")
    p.add_argument("--keywords", default=DEFAULT_KEYWORDS, help="comma list of hype words/phrases")
    p.add_argument("--layout", choices=["center", "blur"], default="center",
                   help="center: crop to 9:16. blur: whole frame over blurred background (gaming)")
    p.add_argument("--crop-x", type=float, default=0.5, help="center layout: 0=left .. 1=right")
    p.add_argument("--no-zoom", action="store_true")
    p.add_argument("--zoom-beat", type=float, default=5.0, help="seconds per zoom push-in")
    p.add_argument("--font", default="Arial")
    p.add_argument("--font-size", type=int, default=84)
    p.add_argument("--caption-margin", type=int, default=480, help="caption height from bottom (px of 1920)")
    p.add_argument("--no-caps", action="store_true", help="don't uppercase captions")
    p.add_argument("--max-height", type=int, default=1080, help="URL video quality cap")
    p.add_argument("--encoder", default="libx264", help="libx264 or h264_nvenc (NVIDIA GPU)")
    p.add_argument("--only", help="render only these ranks, e.g. 1,3,5")
    p.add_argument("--dry-run", action="store_true", help="pick moments + write clips.json, no rendering")
    args = p.parse_args()

    for tool in ["ffmpeg"] + (["yt-dlp"] if is_url(args.source) else []):
        if not shutil.which(tool):
            sys.exit(f"'{tool}' not found. See references/setup.md.")

    out = Path(args.out).resolve()
    cache = out / ".cache"
    cache.mkdir(parents=True, exist_ok=True)

    wav = get_audio(args, cache)
    e = cache / "energy.npy"
    energy = np.load(e) if e.exists() else energy_per_second(wav)
    np.save(e, energy)
    total = len(energy)
    if total < args.min:
        sys.exit("Audio is shorter than the minimum clip length.")
    print(f"Stream length: {hms(total)}")

    n = math.ceil(total / 3600 * args.per_hour) if args.per_hour else args.clips
    n = max(1, n)
    k = max(n + 5, int(n * 2.5))
    win = args.target
    cands = find_candidates(energy, k, win)
    print(f"Found {len(cands)} loud/active candidate moments; transcribing and ranking...")

    full = None
    if args.transcript:
        full = json.loads(Path(args.transcript).read_text())
    elif args.mode == "full":
        full = transcribe_all(wav, total, cache, args.model)

    kws = [x.strip().lower() for x in args.keywords.split(",") if x.strip()]
    pad = 45
    results = []
    for start, escore in cands:
        r0, r1 = max(0, start - pad), min(total, start + win + pad)
        segs = segs_in(full, r0, r1) if full is not None else transcribe_range(wav, r0, r1, cache, args.model)
        clip = build_clip(segs, start, args.min, args.max, args.target)
        if not clip:
            continue
        a, b = clip
        b = min(b, total)
        cs = segs_in(segs, a, b)
        words = [w for s in cs for w in s["words"] if w["end"] > a and w["start"] < b]
        text = " ".join(s["text"] for s in cs)
        results.append({"a": a, "b": b, "escore": escore, "words": words, "text": text,
                        "density": len(words) / max(b - a, 1),
                        "kw": sum(text.lower().count(x) for x in kws),
                        "loud": float(np.log1p(energy[int(a):int(b)]).mean())})
    if not results:
        sys.exit("No usable speech found in the loudest moments. Try --mode full or a larger --model.")

    sc = zscore([r["escore"] for r in results]) + zscore([r["density"] for r in results]) \
        + 0.5 * zscore([r["loud"] for r in results]) + 0.8 * np.array([min(r["kw"], 4) for r in results])
    chosen = []
    for i in np.argsort(-sc):
        r = results[i]
        if all(r["b"] <= c["a"] or r["a"] >= c["b"] for c in chosen):
            r["score"] = float(sc[i])
            chosen.append(r)
        if len(chosen) == n:
            break
    for rank, r in enumerate(chosen, 1):
        r["rank"] = rank

    manifest = [{"rank": r["rank"], "start": round(r["a"], 1), "end": round(r["b"], 1),
                 "duration": round(r["b"] - r["a"], 1), "source_time": tag(r["a"]),
                 "score": round(r["score"], 2), "hype_words": r["kw"], "transcript": r["text"][:600]}
                for r in chosen]
    (out / "clips.json").write_text(json.dumps(manifest, indent=2))
    print(f"Picked {len(chosen)} clips -> {out / 'clips.json'}")
    for m in manifest:
        print(f"  #{m['rank']:02d} {m['source_time']}  {m['duration']:.0f}s  {m['transcript'][:70]}")
    if args.dry_run:
        return

    only = {int(x) for x in args.only.split(",")} if args.only else None
    for r in chosen:
        if only and r["rank"] not in only:
            continue
        a, b = r["a"], r["b"]
        print(f"Rendering clip {r['rank']}/{len(chosen)} ({tag(a)}, {b - a:.0f}s)")
        work = cache / f"clip{r['rank']:02d}"
        work.mkdir(exist_ok=True)
        ass = work / "cap.ass"
        make_ass(r["words"], a, ass, args.font, args.font_size, not args.no_caps, args.caption_margin)
        if is_url(args.source):
            a0, b0 = max(0, math.floor(a) - 2), math.ceil(b) + 2
            src = work / "src.mp4"
            fetch_section(args.source, a0, b0, src, args.max_height)
            ss = a - a0
        else:
            src, ss = Path(args.source).resolve(), a
        render(src, ss, b - a, ass, out / f"clip_{r['rank']:02d}_{tag(a)}.mp4", args)
    print(f"Done. Clips are in {out}")


if __name__ == "__main__":
    main()
